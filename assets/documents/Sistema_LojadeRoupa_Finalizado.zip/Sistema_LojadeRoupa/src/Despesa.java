
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author ingrid.bbastos
 */
public class Despesa extends javax.swing.JFrame {

   //Variável Global
    double despesaTotal = 0.0;
    double receitaTotal = 0.0;
    public Despesa() {
        initComponents();
        setLocationRelativeTo(null); // Centraliza a janela
    carregarDespesasDoArquivo();
}
public void carregarDespesasDoArquivo() {
    File arquivo = new File("despesas.txt");

    if (arquivo.exists()) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(arquivo));
            String linha;
            DefaultTableModel modelo = (DefaultTableModel) Produtos.getModel();
            modelo.setRowCount(0);

            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                if (dados.length == 4) {
                    modelo.addRow(new Object[]{dados[0], dados[1], dados[2], dados[3]});
                }
            }

            br.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao carregar despesas: " + ex.getMessage());
        }
    }
}public void removerLinhaDoArquivo(String nomeArquivo, String data, String descricao, String valor, String parcelas) {
    File arquivo = new File(nomeArquivo);
    File temp = new File("temp.txt");

    try (
        BufferedReader br = new BufferedReader(new FileReader(arquivo));
        BufferedWriter bw = new BufferedWriter(new FileWriter(temp))
    ) {
        String linha;
        while ((linha = br.readLine()) != null) {
            if (!linha.trim().equals(data + ";" + descricao + ";" + valor + ";" + parcelas)) {
                bw.write(linha);
                bw.newLine();
            }
        }

        br.close();
        bw.close();

        arquivo.delete();
        temp.renameTo(arquivo);

    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Erro ao excluir do arquivo: " + e.getMessage());
    }
}
    public double calcularSaldoTotal(String nomeArquivo) {
    double total = 0.0; // Aqui começamos com o total valendo 0

    try (
        // Lê o arquivo linha por linha
        BufferedReader br = new BufferedReader(new FileReader(nomeArquivo))
    ) {
        String linha;

        // Vai lendo cada linha do arquivo até acabar
        while ((linha = br.readLine()) != null) {
            // Divide a linha em partes, usando o ponto e vírgula como separador
            String[] dados = linha.split(";");

            // Aqui a gente pega a coluna onde está o valor
            // Exemplo: se o valor estiver na terceira coluna, usamos o índice 2 (porque começa do 0)
            double valor = Double.parseDouble(dados[2].replace(",", ".")); // troca vírgula por ponto só pra garantir

            // Soma o valor com o total
            total += valor;
        }

    } catch (IOException | NumberFormatException e) {
        // Se der erro lendo o arquivo ou convertendo o número, mostra mensagem
        JOptionPane.showMessageDialog(null, "Erro ao calcular total: " + e.getMessage());
    }

    return total; // No final, devolve o valor total somado
}
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Data = new javax.swing.JTextField();
        Descrição = new javax.swing.JTextField();
        Valor = new javax.swing.JTextField();
        Parcelas = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Produtos = new javax.swing.JTable();
        LançarDespesa = new javax.swing.JButton();
        Cancelar = new javax.swing.JButton();
        Voltar = new javax.swing.JButton();
        SomaDespesa = new javax.swing.JButton();
        totalSaldo = new javax.swing.JButton();
        ExcluirDespesa = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Despesa");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 153, 204));

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel1.setText("DESPESAS");

        jLabel2.setText("Data:");

        jLabel3.setText("Descrição:");

        jLabel4.setText("Valor (R$):");

        jLabel5.setText("Parcelas:");

        Produtos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Data", "Descrição", "Valor", "Parcelas"
            }
        ));
        jScrollPane1.setViewportView(Produtos);
        if (Produtos.getColumnModel().getColumnCount() > 0) {
            Produtos.getColumnModel().getColumn(0).setResizable(false);
            Produtos.getColumnModel().getColumn(1).setResizable(false);
            Produtos.getColumnModel().getColumn(2).setResizable(false);
            Produtos.getColumnModel().getColumn(3).setResizable(false);
        }

        LançarDespesa.setText("Lançar Despesa");
        LançarDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LançarDespesaActionPerformed(evt);
            }
        });

        Cancelar.setText("Cancelar");
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });

        Voltar.setBackground(new java.awt.Color(204, 255, 255));
        Voltar.setText("Voltar");
        Voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VoltarActionPerformed(evt);
            }
        });

        SomaDespesa.setText("Despesa Total");
        SomaDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SomaDespesaActionPerformed(evt);
            }
        });

        totalSaldo.setText("Saldo Total");
        totalSaldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalSaldoActionPerformed(evt);
            }
        });

        ExcluirDespesa.setText("Excluir Despesa");
        ExcluirDespesa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirDespesaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Data)
                                    .addComponent(Descrição)
                                    .addComponent(Valor)
                                    .addComponent(Parcelas, javax.swing.GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Cancelar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(LançarDespesa)))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(333, 333, 333)
                        .addComponent(ExcluirDespesa)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(SomaDespesa)
                        .addGap(18, 18, 18)
                        .addComponent(totalSaldo))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(326, 326, 326)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(Voltar)))
                .addContainerGap(61, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(Descrição, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(Data, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(Valor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(Parcelas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(LançarDespesa)
                            .addComponent(Cancelar)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel1)
                        .addGap(31, 31, 31)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(totalSaldo)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(SomaDespesa)
                        .addComponent(ExcluirDespesa)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addComponent(Voltar)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LançarDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LançarDespesaActionPerformed
        // Lançamento da Despesa
        String data = Data.getText();
        String parcelas = Parcelas.getText();
        String valor = Valor.getText();
        String descrição = Descrição.getText();
        DefaultTableModel tblProdutos = (DefaultTableModel) Produtos.getModel();  
        Object[]novoProduto ={Data.getText(),Parcelas.getText(),Valor.getText(), Descrição.getText()};
     

       JOptionPane.showMessageDialog(null, "Despesa lançada com sucesso!");
       tblProdutos.addRow(novoProduto); 
       
       try (BufferedWriter bw = new BufferedWriter(new FileWriter("despesas.txt", true))) {
    String linha = Data.getText() + ";" + Descrição.getText() + ";" + Valor.getText() + ";" + Parcelas.getText();
    bw.write(linha);
    bw.newLine();
} catch (IOException ex) {
    JOptionPane.showMessageDialog(null, "Erro ao salvar despesa: " + ex.getMessage());
}

    }//GEN-LAST:event_LançarDespesaActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
        // Apagar texto
        Descrição.setText("");
     Parcelas.setText("");
     Valor.setText("");
Data.setText("");
    }//GEN-LAST:event_CancelarActionPerformed

    private void VoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VoltarActionPerformed
        // Voltar para o Menu
        new Menu().setVisible(true);
        dispose();// fecha a janela atual
    }//GEN-LAST:event_VoltarActionPerformed

    private void SomaDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SomaDespesaActionPerformed
        // Somar Despesa
        SomaDespesa.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        despesaTotal = 0.0; // Zera antes de somar

        int colunaValor = -1;

        // Descobre o índice da coluna "Valor"
        for (int i = 0; i < Produtos.getColumnCount(); i++) {
            String nomeColuna = Produtos.getColumnName(i).trim().toLowerCase();
            if (nomeColuna.contains("valor")) {
                colunaValor = i;
                break;
            }
        }

        if (colunaValor != -1) {
            for (int i = 0; i < Produtos.getRowCount(); i++) {
                Object valorObj = Produtos.getValueAt(i, colunaValor);

                if (valorObj != null && !valorObj.toString().isEmpty()) {
                    try {
                        String texto = valorObj.toString()
                            .replace("R$", "")
                            .replace(".", "")
                            .replace(",", ".")
                            .trim();

                        double valor = Double.parseDouble(texto);
                        despesaTotal += valor;

                    } catch (NumberFormatException ex) {
                        System.out.println("Erro ao ler valor na linha " + i + ": " + valorObj);
                    }
                }
            }

            JOptionPane.showMessageDialog(null, "Despesa Total: R$ " + String.format("%.2f", despesaTotal));
        } else {
            JOptionPane.showMessageDialog(null, "Coluna 'Valor' não encontrada na tabela de despesas.");
        }
    }
});
    }//GEN-LAST:event_SomaDespesaActionPerformed

    private void totalSaldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalSaldoActionPerformed
 double receitaTotal = calcularSaldoTotal ("receitas.txt");
 double despesaTotal = calcularSaldoTotal ("despesas.txt");
 double saldo = receitaTotal - despesaTotal;
 
 String mensagem = "Receita total: R$ " + String.format("%.2f", receitaTotal) + "\nDespesa Total: R$ " + String.format( "%.2f", despesaTotal)  + "\n Saldo Total: R$ " + String.format("%.2f", saldo);
 
 JOptionPane.showMessageDialog(null,mensagem);

    }//GEN-LAST:event_totalSaldoActionPerformed

    private void ExcluirDespesaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExcluirDespesaActionPerformed
        ExcluirDespesa.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            int linhaSelecionada = Produtos.getSelectedRow();

            if (linhaSelecionada != -1) {
                // Pegando os dados da linha com base nos nomes corretos das colunas
                String data = Produtos.getValueAt(linhaSelecionada, 0).toString();
                String descricao = Produtos.getValueAt(linhaSelecionada, 1).toString();
                String valor = Produtos.getValueAt(linhaSelecionada, 2).toString();
                String parcelas = Produtos.getValueAt(linhaSelecionada, 3).toString();

                // Remove da tabela
                DefaultTableModel modelo = (DefaultTableModel) Produtos.getModel();
                modelo.removeRow(linhaSelecionada);

                // Remove do arquivo
                removerLinhaDoArquivo("despesas.txt", data, descricao, valor, parcelas);

                JOptionPane.showMessageDialog(null, "Despesa excluída com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Selecione uma linha para excluir!");
            }
        }

            private void removerLinhaDoArquivo(String despesastxt, String data, String descricao, String valor, String parcelas) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
    });

    }//GEN-LAST:event_ExcluirDespesaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Despesa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Despesa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Despesa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Despesa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Despesa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cancelar;
    private javax.swing.JTextField Data;
    private javax.swing.JTextField Descrição;
    private javax.swing.JButton ExcluirDespesa;
    private javax.swing.JButton LançarDespesa;
    private javax.swing.JTextField Parcelas;
    private javax.swing.JTable Produtos;
    private javax.swing.JButton SomaDespesa;
    private javax.swing.JTextField Valor;
    private javax.swing.JButton Voltar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton totalSaldo;
    // End of variables declaration//GEN-END:variables


}
