
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

  
/**
 *
 * @author ingrid.bbastos
 */
public class Receita extends javax.swing.JFrame {
        double receitaTotal = 0.0;
    
    public Receita() {
        initComponents();
        setLocationRelativeTo(null); // Centraliza a janela
        carregarReceitasDoArquivo();  // Chamada para carregar os dados na tabela
    }

    // Carrega o .txt pra tabela, para quando abrir o sistema a tabela ficar com os valores salvos (usaremos isso para saber o saldo da empresa)
    public void carregarReceitasDoArquivo() { //tava pesquisando e existe public void e public double, o void serve só quando a função não precisa retornar um valor
        File arquivo = new File("receitas.txt");

        if (arquivo.exists()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(arquivo));
                String linha;
                DefaultTableModel modelo = (DefaultTableModel) Produtos.getModel();
                modelo.setRowCount(0); // limpa a tabela antes de carregar

                while ((linha = br.readLine()) != null) {
                    String[] dados = linha.split(";");
                    if (dados.length == 4) {
                        modelo.addRow(new Object[]{dados[0], dados[1], dados[2], dados[3]});
                    }
                }

                br.close();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Erro ao carregar receitas: " + ex.getMessage());
            }
        }
    }
public void removerLinhaDoArquivo(String nomeArquivo, String data, String nome, String valor, String pagamento) {
    File arquivo = new File(nomeArquivo);
    File temp = new File("temp.txt");

    try (
        BufferedReader br = new BufferedReader(new FileReader(arquivo));
        BufferedWriter bw = new BufferedWriter(new FileWriter(temp))
    ) {
        String linha;
        while ((linha = br.readLine()) != null) {
            if (!linha.trim().equals(data + ";" + nome + ";" + valor + ";" + pagamento)) {
                bw.write(linha);
                bw.newLine();
            }
        }

        br.close();
        bw.close();

        // Substitui o original pelo temporário
        arquivo.delete();
        temp.renameTo(arquivo);

    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Erro ao excluir do arquivo: " + e.getMessage());
    }
}

public double calcularSaldoTotal(String nomeArquivo) {
    double total = 0.0; // Aqui começamos com o total valendo 0

    try (
        // Lê o arquivo linha por linha
        BufferedReader br = new BufferedReader(new FileReader(nomeArquivo))
    ) {
        String linha;

        // Vai lendo cada linha do arquivo até acabar
        while ((linha = br.readLine()) != null) {
            // Divide a linha em partes, usando o ponto e vírgula como separador
            String[] dados = linha.split(";");

            // Aqui a gente pega a coluna onde está o valor
            // Exemplo: se o valor estiver na terceira coluna, usamos o índice 2 (porque começa do 0)
            double valor = Double.parseDouble(dados[2].replace(",", ".")); // troca vírgula por ponto só pra garantir

            // Soma o valor com o total
            total += valor;
        }

    } catch (IOException | NumberFormatException e) {
        // Se der erro lendo o arquivo ou convertendo o número, mostra mensagem
        JOptionPane.showMessageDialog(null, "Erro ao calcular total: " + e.getMessage());
    }

    return total; // No final, devolve o valor total somado
}
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Produtos = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Data = new javax.swing.JTextField();
        Nome = new javax.swing.JTextField();
        Valor = new javax.swing.JTextField();
        NotaFiscal = new javax.swing.JButton();
        CancelarTexto = new javax.swing.JButton();
        Voltar = new javax.swing.JButton();
        Pagamento = new javax.swing.JTextField();
        SomaReceita = new javax.swing.JButton();
        ExcluirReceita = new javax.swing.JButton();
        totalSaldo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Receita");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 153, 204));

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel1.setText("RECEITA");

        Produtos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Data", "Nome do Produto", "Valor do Produto", "Forma de Pagamento"
            }
        ));
        jScrollPane1.setViewportView(Produtos);
        if (Produtos.getColumnModel().getColumnCount() > 0) {
            Produtos.getColumnModel().getColumn(0).setResizable(false);
            Produtos.getColumnModel().getColumn(1).setResizable(false);
            Produtos.getColumnModel().getColumn(2).setResizable(false);
        }

        jLabel2.setText("Data:");

        jLabel3.setText("Nome do Produto:");

        jLabel4.setText("Valor (R$):");

        jLabel5.setText("Forma de Pagamento:");

        Valor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ValorActionPerformed(evt);
            }
        });

        NotaFiscal.setText("Lançar Nota Fiscal");
        NotaFiscal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NotaFiscalActionPerformed(evt);
            }
        });

        CancelarTexto.setText("Cancelar");
        CancelarTexto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarTextoActionPerformed(evt);
            }
        });

        Voltar.setBackground(new java.awt.Color(204, 255, 255));
        Voltar.setText("Voltar");
        Voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VoltarActionPerformed(evt);
            }
        });

        SomaReceita.setText("Receita Total");
        SomaReceita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SomaReceitaActionPerformed(evt);
            }
        });

        ExcluirReceita.setText("Excluir Receita");
        ExcluirReceita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirReceitaActionPerformed(evt);
            }
        });

        totalSaldo.setText("Saldo Total");
        totalSaldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalSaldoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Nome)
                    .addComponent(Data, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Valor, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(CancelarTexto)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(NotaFiscal))
                    .addComponent(Pagamento, javax.swing.GroupLayout.Alignment.LEADING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 510, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(96, 96, 96))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Voltar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ExcluirReceita)
                .addGap(26, 26, 26)
                .addComponent(SomaReceita)
                .addGap(18, 18, 18)
                .addComponent(totalSaldo)
                .addGap(167, 167, 167))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(Nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(Data, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(Valor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(Pagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(NotaFiscal)
                            .addComponent(CancelarTexto)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SomaReceita)
                    .addComponent(ExcluirReceita)
                    .addComponent(totalSaldo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 103, Short.MAX_VALUE)
                .addComponent(Voltar)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 900, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CancelarTextoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarTextoActionPerformed
        // Apagar o texto
     Pagamento.setText("");
     Nome.setText("");
     Valor.setText("");
    Data.setText("");
    }//GEN-LAST:event_CancelarTextoActionPerformed

    private void NotaFiscalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NotaFiscalActionPerformed
        // Lançamento Nota Fiscal
 
        String nome = Nome.getText();
        String data = Data.getText();
        String valor = Valor.getText();
        String pagamento = Pagamento.getText();
        DefaultTableModel tblProdutos = (DefaultTableModel) Produtos.getModel();  
        Object[]novoProduto ={Nome.getText(),Data.getText(),Valor.getText(), Pagamento.getText()};
     

       JOptionPane.showMessageDialog(null, "Nota Fiscal lançada com sucesso!");
       tblProdutos.addRow(novoProduto); 
       
       //Assim que lançar, salva as informações no arquivo txt também
       try { //Try Tenta executar um código que pode dar erro
    FileWriter fw = new FileWriter("receitas.txt", true); // true = adicionar sem apagar o que já tem
    BufferedWriter bw = new BufferedWriter(fw);

    // Variáveis e colunas da tabela a serem salvas as informações
    String data1 = Data.getText();
    String nome1 = Nome.getText();
    String valor1 = Valor.getText();
    String pagamento1 = Pagamento.getText();

    // Formata e grava a linha que acabou de ser lançada na tabela no arquivo txt
    bw.write(data1 + ";" + nome1 + ";" + valor1 + ";" + pagamento1);
    bw.newLine(); // pula linha

    bw.close();
    fw.close();

} catch (IOException ex) { //Catch Executa caso dê erro, pra evitar que o sistema quebre
    JOptionPane.showMessageDialog(null, "Erro ao salvar no arquivo: " + ex.getMessage()); //executa essa mensagem caso dê erro
}

    }//GEN-LAST:event_NotaFiscalActionPerformed

    private void SomaReceitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SomaReceitaActionPerformed
        
     // variável botão
SomaReceita.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        receitaTotal = 0.0; // Zera antes de somar de novo

        int colunaValor = -1;

        // Descobre o índice da coluna "Valor"
        for (int i = 0; i < Produtos.getColumnCount(); i++) {
            if (Produtos.getColumnName(i).equalsIgnoreCase("Valor do Produto")) {
                colunaValor = i;
                break;
            }
        }

        // Se encontrou a coluna "Valor"
        if (colunaValor != -1) {
            for (int i = 0; i < Produtos.getRowCount(); i++) {
                Object valorObj = Produtos.getValueAt(i, colunaValor);

                if (valorObj != null && !valorObj.toString().isEmpty()) {
                    try {
                        // Formata o valor: remove R$, pontos, troca vírgula por ponto
                        String texto = valorObj.toString()
                            .replace("R$", "")
                            .replace(".", "")
                            .replace(",", ".")
                            .trim();

                        double valor = Double.parseDouble(texto);
                        receitaTotal += valor;

                    } catch (NumberFormatException ex) {
                        System.out.println("Erro ao converter valor na linha " + i + ": " + valorObj);
                    }
                }
            }

            // Exibe o total formatado
            JOptionPane.showMessageDialog(null, "Receita Total: R$ " + String.format("%.2f", receitaTotal));
        } else {
            // Caso a coluna "Valor" não seja encontrada
            JOptionPane.showMessageDialog(null, "Coluna 'Valor' não encontrada na tabela.");
        }
    }
});
    }//GEN-LAST:event_SomaReceitaActionPerformed

    private void ValorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ValorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ValorActionPerformed

    private void ExcluirReceitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExcluirReceitaActionPerformed
       //Excluir receita da tabela e também do arquivo txt
        ExcluirReceita.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int linhaSelecionada = Produtos.getSelectedRow();

        if (linhaSelecionada != -1) {
            // Pega os dados da linha selecionada
            String data = Produtos.getValueAt(linhaSelecionada, 0).toString();
            String nome = Produtos.getValueAt(linhaSelecionada, 1).toString();
            String valor = Produtos.getValueAt(linhaSelecionada, 2).toString();
            String pagamento = Produtos.getValueAt(linhaSelecionada, 3).toString();

            // Remove da tabela
            DefaultTableModel modelo = (DefaultTableModel) Produtos.getModel();
            modelo.removeRow(linhaSelecionada);

            // Remove do arquivo
            removerLinhaDoArquivo("receitas.txt", data, nome, valor, pagamento);

            JOptionPane.showMessageDialog(null, "Receita excluída com sucesso!");
        } else {
            JOptionPane.showMessageDialog(null, "Selecione uma linha para excluir.");
        }
    }
});
    }//GEN-LAST:event_ExcluirReceitaActionPerformed

    private void VoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VoltarActionPerformed
        // Voltar para o Menu
         new Menu().setVisible(true);
        dispose(); 

    }//GEN-LAST:event_VoltarActionPerformed

    private void totalSaldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalSaldoActionPerformed
    double receitaTotal = calcularSaldoTotal ("receitas.txt");
    double despesaTotal = calcularSaldoTotal ("despesas.txt");
    double saldo = receitaTotal - despesaTotal;

    String mensagem = "Receita total: R$ " + String.format("%.2f", receitaTotal) + "\nDespesa Total: R$ " + String.format( "%.2f", despesaTotal)  + "\n Saldo Total: R$ " + String.format("%.2f", saldo);

    JOptionPane.showMessageDialog(null,mensagem);

    
    }//GEN-LAST:event_totalSaldoActionPerformed

    /**
     * @param args the command line arguments
     */
     public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Receita().setVisible(true); 
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CancelarTexto;
    private javax.swing.JTextField Data;
    private javax.swing.JButton ExcluirReceita;
    private javax.swing.JTextField Nome;
    private javax.swing.JButton NotaFiscal;
    private javax.swing.JTextField Pagamento;
    private javax.swing.JTable Produtos;
    private javax.swing.JButton SomaReceita;
    private javax.swing.JTextField Valor;
    private javax.swing.JButton Voltar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton totalSaldo;
    // End of variables declaration//GEN-END:variables
}
