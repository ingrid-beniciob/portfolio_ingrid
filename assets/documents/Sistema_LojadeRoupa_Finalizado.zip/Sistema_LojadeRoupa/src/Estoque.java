
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author ingrid.bbastos
 */
public class Estoque extends javax.swing.JFrame {

    /**
     * Creates new form Estoque
     */
    public Estoque() {
          initComponents(); 
          setLocationRelativeTo(null); // Centraliza a janela
        carregarEstoqueDoArquivo();  // Chamada para carregar os dados na tabela
    }

    // Carrega o .txt pra tabela, para quando abrir o sistema a tabela ficar com os valores salvos  
    public void carregarEstoqueDoArquivo() {
        File arquivo = new File("estoque.txt");

        if (arquivo.exists()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(arquivo));
                String linha;
                DefaultTableModel modelo = (DefaultTableModel) Produtos.getModel();
                modelo.setRowCount(0); // limpa a tabela antes de carregar

                while ((linha = br.readLine()) != null) {
                    String[] dados = linha.split(";");
                    if (dados.length == 4) {
                        modelo.addRow(new Object[]{dados[0], dados[1], dados[2], dados[3]});
                    }
                }

                br.close();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Erro ao carregar seu Estoque: " + ex.getMessage());
            }
        }
    }

    public void removerLinhaDoArquivo (String nomeArquivo, String cadastro1, String id1, String valor1, String quantidade1) {
    File arquivo = new File(nomeArquivo);
    File temp = new File("temp.txt");

    try (
        BufferedReader br = new BufferedReader(new FileReader(arquivo));
        BufferedWriter bw = new BufferedWriter(new FileWriter(temp))
    ) {
        String linha;
        while ((linha = br.readLine()) != null) {
            if (!linha.trim().equals(cadastro1 + ";" + id1 + ";" + valor1 + ";" + quantidade1)) {
                bw.write(linha);
                bw.newLine();
            }
        }

        br.close();
        bw.close();

        // Substitui o original pelo temporário
        arquivo.delete();
        temp.renameTo(arquivo);

    } catch (IOException e) {
        JOptionPane.showMessageDialog(null, "Erro ao excluir do arquivo: " + e.getMessage());
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        ID = new javax.swing.JTextField();
        Nome = new javax.swing.JTextField();
        Valor = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Produtos = new javax.swing.JTable();
        Cadastrar = new javax.swing.JButton();
        Cancelar = new javax.swing.JButton();
        Voltar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        Quantidade = new javax.swing.JTextField();
        ExcluirEstoque = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Estoque");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 153, 204));

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel1.setText("ESTOQUE");

        jLabel2.setText("ID Produto:");

        jLabel3.setText("Nome do Produto:");

        jLabel4.setText("Valor (R$):");

        Produtos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome do Produto", "Valor", "Quantidade"
            }
        ));
        jScrollPane1.setViewportView(Produtos);
        if (Produtos.getColumnModel().getColumnCount() > 0) {
            Produtos.getColumnModel().getColumn(0).setResizable(false);
            Produtos.getColumnModel().getColumn(2).setResizable(false);
            Produtos.getColumnModel().getColumn(3).setResizable(false);
        }

        Cadastrar.setText("Cadastrar");
        Cadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CadastrarActionPerformed(evt);
            }
        });

        Cancelar.setText("Cancelar");
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });

        Voltar.setBackground(new java.awt.Color(204, 255, 255));
        Voltar.setText("Voltar");
        Voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VoltarActionPerformed(evt);
            }
        });

        jLabel5.setText("Quantidade:");

        ExcluirEstoque.setText("Excluir Estoque");
        ExcluirEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirEstoqueActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(Voltar))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(ExcluirEstoque)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(130, 130, 130)
                                    .addComponent(Cancelar)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(Cadastrar))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(21, 21, 21)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING))
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(ID, javax.swing.GroupLayout.DEFAULT_SIZE, 189, Short.MAX_VALUE)
                                                .addComponent(Nome)
                                                .addComponent(Valor)))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                            .addGap(6, 6, 6)
                                            .addComponent(Quantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGap(34, 34, 34)
                                    .addComponent(jLabel1))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ExcluirEstoque)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ID, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(Nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Valor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(Quantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Cancelar)
                    .addComponent(Cadastrar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(Voltar)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CadastrarActionPerformed
        // TODO add your handling code here:
        String cadastro = Nome.getText();
        String id = ID.getText();
        String valor = Valor.getText();
         String quantidade = Quantidade.getText();
         
        DefaultTableModel tblProdutos = (DefaultTableModel) Produtos.getModel();  
        Object[]novoProduto ={Nome.getText(),ID.getText(),Valor.getText(),Quantidade.getText()};
     
           JOptionPane.showMessageDialog(null, "Cadastro feito com sucesso!");
       tblProdutos.addRow(novoProduto); 
       
       //Assim que lançar, salva as informações no arquivo txt também
       try { //Try Tenta executar um código que pode dar erro
    FileWriter fw = new FileWriter("estoque.txt", true); // true = adicionar sem apagar o que já tem
    BufferedWriter bw = new BufferedWriter(fw);

    // Variáveis e colunas da tabela a serem salvas as informações
    String cadastrotxt = Nome.getText();
    String idtxt = ID.getText();
    String valortxt = Valor.getText();
    String quantidadetxt = Quantidade.getText();

    // Formata e grava a linha que acabou de ser lançada na tabela no arquivo txt
    bw.write(cadastrotxt + ";" + idtxt + ";" + valortxt + ";" + quantidadetxt);
    bw.newLine(); // pula linha

    bw.close();
    fw.close();

} catch (IOException ex) { //Catch Executa caso dê erro, pra evitar que o sistema quebre
    JOptionPane.showMessageDialog(null, "Erro ao salvar no arquivo: " + ex.getMessage()); //executa essa mensagem caso dê erro
}

                          

    }//GEN-LAST:event_CadastrarActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed
        // TODO add your handling code here:
         ID.setText("");
      Nome.setText("");
      Valor.setText("");
Quantidade.setText("");
    }//GEN-LAST:event_CancelarActionPerformed

    private void VoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VoltarActionPerformed
        // TODO add your handling code here:
        new Menu().setVisible(true);
        dispose();// fecha a janela atual
    }//GEN-LAST:event_VoltarActionPerformed

    private void ExcluirEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExcluirEstoqueActionPerformed
          //Excluir receita da tabela e também do arquivo txt
        ExcluirEstoque.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int linhaSelecionada = Produtos.getSelectedRow();

        if (linhaSelecionada != -1) {
            // Pega os dados da linha selecionada
            String cadastro1 = Produtos.getValueAt(linhaSelecionada, 0).toString();
            String id1 = Produtos.getValueAt(linhaSelecionada, 1).toString();
            String valor1 = Produtos.getValueAt(linhaSelecionada, 2).toString();
            String quantidade1 = Produtos.getValueAt(linhaSelecionada, 3).toString();

            // Remove da tabela
            DefaultTableModel modelo = (DefaultTableModel) Produtos.getModel();
            modelo.removeRow(linhaSelecionada);

            // Remove do arquivo
            removerLinhaDoArquivo("estoque.txt", cadastro1, id1, valor1, quantidade1);

            JOptionPane.showMessageDialog(null, "Estoque excluido com sucesso!");
        } else {
            JOptionPane.showMessageDialog(null, "Selecione uma linha para excluir.");
        }
    }
});                                            

         
    }//GEN-LAST:event_ExcluirEstoqueActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Estoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Estoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Estoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Estoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Estoque().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cadastrar;
    private javax.swing.JButton Cancelar;
    private javax.swing.JButton ExcluirEstoque;
    private javax.swing.JTextField ID;
    private javax.swing.JTextField Nome;
    private javax.swing.JTable Produtos;
    private javax.swing.JTextField Quantidade;
    private javax.swing.JTextField Valor;
    private javax.swing.JButton Voltar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
