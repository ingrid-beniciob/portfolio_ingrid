from conexao_db import conectar_banco

class ContasDB:
    
    # INSERIR CONTA NO BANCO
    @staticmethod
    def inserir_conta(tipo, descricao, valor, vencimento, forma_pagamento='A pagar', cliente_id=None, status='aberta'):
        # Conecta com o banco
        conexao = conectar_banco()  
        if conexao:
            try:
                cursor = conexao.cursor()
                # SQL para inserir conta - 7 campos na tabela
                sql = """INSERT INTO contas 
                         (tipo, descricao, valor, vencimento, status, forma_pagamento, cliente_id) 
                         VALUES (%s, %s, %s, %s, %s, %s, %s)"""
                # Valores na mesma ordem do SQL - 7 valores
                valores = (tipo, descricao, valor, vencimento, status, forma_pagamento, cliente_id)
                cursor.execute(sql, valores)
                conexao.commit()
                return True, "Conta inserida com sucesso"
            except Exception as e:  
                return False, f"Erro no banco: {e}"
            finally:
                # Fecha conexão
                cursor.close()
                conexao.close()
        return False, "Erro de conexão"
    
    # BUSCAR CONTAS COM FILTROS
    @staticmethod
    def buscar_contas(filtro_tipo=None, filtro_status=None, data_fim=None, busca_texto=None):
        conexao = conectar_banco()
        if conexao:
            try:
                cursor = conexao.cursor()
                
                # SQL base
                sql = "SELECT * FROM contas WHERE 1=1"
                valores = []
                
                # Adiciona filtros se existirem
                if filtro_tipo:
                    sql += " AND tipo = %s"
                    valores.append(filtro_tipo)
                
                if filtro_status:
                    sql += " AND status = %s"
                    valores.append(filtro_status)
                
                if data_fim:
                    sql += " AND vencimento <= %s"
                    valores.append(data_fim)
                
                if busca_texto:
                    sql += " AND descricao LIKE %s"
                    valores.append(f'%{busca_texto}%')
                
                # Ordena por data de vencimento
                sql += " ORDER BY vencimento ASC"
                
                cursor.execute(sql, valores)
                contas = cursor.fetchall()
                return True, contas
                
            except Exception as e:
                return False, f"Erro no banco: {e}"
            finally:
                cursor.close()
                conexao.close()
        return False, "Erro de conexão"
    
    # ATUALIZAR STATUS DA CONTA
    @staticmethod
    def atualizar_status(conta_id, novo_status):
        conexao = conectar_banco()
        if conexao:
            try:
                cursor = conexao.cursor()
                # SQL para atualizar status
                sql = "UPDATE contas SET status = %s WHERE id = %s"
                cursor.execute(sql, (novo_status, conta_id))
                conexao.commit()
                return True, "Status atualizado com sucesso"
            except Exception as e:  
                return False, f"Erro no banco: {e}"
            finally:
                cursor.close()
                conexao.close()
        return False, "Erro de conexão"