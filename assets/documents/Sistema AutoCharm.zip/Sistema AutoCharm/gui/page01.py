#Importa as bibliotecas necessárias
import tkinter #Para interface
from PIL import Image, ImageTk #Para imagem
import os #Para navegar por diretórios e arquivos

# CONFIGURAÇÕES PROFISSIONAIS
CONFIG = {
    "largura_janela": 1000,
    "altura_janela": 700,
    "tamanho_logo": (1500, 650),
    "tamanho_bem_vindo": (500, 200),
    "espaco_acima_logo": 100,
    "espaco_entre_imagens": 5,
    "cor_fundo": "#ffffff",  # Fundo branco 
    
}

# Obtém o diretório do script
diretorio_script = os.path.dirname(__file__)
caminho_imagem1 = os.path.join(diretorio_script, 'images', 'Logo.png')
caminho_imagem2 = os.path.join(diretorio_script, 'images', 'bem_vindo.png')

# Cria a janela principal
page01 = tkinter.Tk()
page01.title("AutoCharm - Mecânica Automotiva")
page01.geometry(f"{CONFIG['largura_janela']}x{CONFIG['altura_janela']}")
page01.configure(bg=CONFIG['cor_fundo'])

# Container para centralizar tudo
frame_central = tkinter.Frame(page01, bg=CONFIG['cor_fundo'])
frame_central.pack(expand=True)


# PRIMEIRA IMAGEM (Logo)
def carregar_imagem(caminho, tamanho):
    try:
        if os.path.exists(caminho):
            imagem = Image.open(caminho)
            imagem_redimensionada = imagem.resize(tamanho, Image.Resampling.LANCZOS)
            return ImageTk.PhotoImage(imagem_redimensionada)
    except Exception as e:
        print(f"Erro ao carregar imagem: {e}")
    return None

imagem_tk1 = carregar_imagem(caminho_imagem1, CONFIG['tamanho_logo'])
if imagem_tk1:
    label_imagem1 = tkinter.Label(frame_central, image=imagem_tk1, bg=CONFIG['cor_fundo'])
    label_imagem1.pack(pady=CONFIG['espaco_entre_imagens'])
else:
    label_erro1 = tkinter.Label(frame_central, text="[LOGO]", font=CONFIG['fonte_texto'], bg=CONFIG['cor_fundo'])
    label_erro1.pack(pady=CONFIG['espaco_entre_imagens'])


# SEGUNDA IMAGEM (bem_vindo)
imagem_tk2 = carregar_imagem(caminho_imagem2, CONFIG['tamanho_bem_vindo'])
if imagem_tk2:
    label_imagem2 = tkinter.Label(frame_central, image=imagem_tk2, bg=CONFIG['cor_fundo'])
    label_imagem2.pack(pady=CONFIG['espaco_entre_imagens'])
else:
    label_erro2 = tkinter.Label(frame_central, text="[IMAGEM DE BOAS-VINDAS]", font=CONFIG['fonte_texto'], bg=CONFIG['cor_fundo'])
    label_erro2.pack(pady=CONFIG['espaco_entre_imagens'])

page01.mainloop()