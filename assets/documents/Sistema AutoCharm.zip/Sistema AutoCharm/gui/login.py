# Importa as bibliotecas necessárias
import tkinter  # Para interface gráfica
from PIL import Image, ImageTk  # Para manipular imagens
import os  # Para navegar por diretórios e arquivos

# CONFIGURAÇÕES PROFISSIONAIS DA TELA DE LOGIN
CONFIG = {
    "largura_janela": 1200,  # Largura aumentada para caber header lateral
    "altura_janela": 700,    # Altura mantida
    "tamanho_logo": (400, 150),  # Tamanho da logo (largura, altura)
    "tamanho_perfil": (260, 220),  # Tamanho do perfil (largura, altura)
    "largura_header": 450,   # Largura do header vertical
    "espaco_interno": 20,    # Espaço interno entre elementos
    "cor_fundo": "#ffffff",  # Fundo branco 
    "cor_borda": "#000000",  # Cor preta para a borda
    "cor_header": "#de0000", # Cor vermelha para o header
    "fonte_titulo": ("Arial", 16, "bold"),
    "fonte_texto": ("Arial", 12),
    "fonte_campos": ("Arial", 11)
}

# Obtém o diretório onde o script está localizado
diretorio_script = os.path.dirname(__file__)

# Monta os caminhos completos para as imagens
caminho_logo = os.path.join(diretorio_script, 'images', 'logo2.png')
caminho_perfil = os.path.join(diretorio_script, 'images', 'perfil.png')  # Imagem do perfil

# Cria a janela principal da aplicação
page01 = tkinter.Tk()
page01.title("AutoCharm - Sistema de Login")
page01.geometry(f"{CONFIG['largura_janela']}x{CONFIG['altura_janela']}")
page01.configure(bg=CONFIG['cor_borda'])  # Fundo preto para a borda

# Função para carregar e redimensionar imagens
def carregar_imagem(caminho, tamanho):
    """Carrega uma imagem e redimensiona para o tamanho especificado"""
    try:
        if os.path.exists(caminho):
            imagem = Image.open(caminho)
            imagem_redimensionada = imagem.resize(tamanho, Image.Resampling.LANCZOS)
            return ImageTk.PhotoImage(imagem_redimensionada)
    except Exception as e:
        print(f"Erro ao carregar imagem: {e}")
    return None

# Container principal com borda preta
frame_principal = tkinter.Frame(page01, bg=CONFIG['cor_borda'], padx=3, pady=3)
frame_principal.pack(expand=True, fill='both', padx=20, pady=20)

# Container interno branco (área principal) - organizado horizontalmente
frame_interno = tkinter.Frame(frame_principal, bg=CONFIG['cor_fundo'])
frame_interno.pack(expand=True, fill='both')

# HEADER VERTICAL VERMELHO (lado esquerdo)
frame_header = tkinter.Frame(
    frame_interno, 
    bg=CONFIG['cor_header'], 
    width=CONFIG['largura_header']
)
frame_header.pack(side='left', fill='y')
frame_header.pack_propagate(False)  # Mantém a largura fixa

# Conteúdo do header vertical
frame_header_conteudo = tkinter.Frame(frame_header, bg=CONFIG['cor_header'])
frame_header_conteudo.pack(expand=True, fill='both', padx=20, pady=40)

# Logo no header vertical (centralizada) - TAMANHO CONTROLADO POR CONFIG['tamanho_logo']
imagem_logo = carregar_imagem(caminho_logo, CONFIG['tamanho_logo'])

if imagem_logo:
    label_logo = tkinter.Label(frame_header_conteudo, image=imagem_logo, bg=CONFIG['cor_header'])
    label_logo.pack(pady=(0, 30))
else:
    label_logo_erro = tkinter.Label(
        frame_header_conteudo, 
        text="AUTOCHARM\nMECÂNICA\nAUTOMOTIVA", 
        font=("Arial", 14, "bold"), 
        bg=CONFIG['cor_header'], 
        fg="white",
        justify='center'
    )
    label_logo_erro.pack(pady=(0, 30))


# Texto "Accessor" no rodapé do header vertical
label_accessor_header = tkinter.Label(
    frame_header_conteudo,
    text="Accessor",
    font=("Arial", 10, "italic"),
    bg=CONFIG['cor_header'],
    fg="white"
)
label_accessor_header.pack(side='bottom')

# Área do formulário de login (lado direito)
frame_login_area = tkinter.Frame(frame_interno, bg=CONFIG['cor_fundo'])
frame_login_area.pack(expand=True, fill='both', side='right')

# Container central para o formulário de login
frame_login = tkinter.Frame(frame_login_area, bg=CONFIG['cor_fundo'])
frame_login.place(relx=0.5, rely=0.5, anchor='center')  # Centraliza vertical e horizontalmente

# Título do sistema
label_titulo_sistema = tkinter.Label(
    frame_login, 
    text="BEM VINDO!",
    font=("Arial", 20, "bold"),
    bg=CONFIG['cor_fundo'],
    fg="#333333"
)
label_titulo_sistema.pack(pady=(0, 30))

# Imagem de perfil (centro) - TAMANHO CONTROLADO POR CONFIG['tamanho_perfil']
imagem_perfil = carregar_imagem(caminho_perfil, CONFIG['tamanho_perfil'])
if imagem_perfil:
    label_perfil = tkinter.Label(frame_login, image=imagem_perfil, bg=CONFIG['cor_fundo'])
    label_perfil.pack(pady=(0, 30))
else:
    # Placeholder circular para perfil
    canvas_perfil = tkinter.Canvas(frame_login, width=120, height=120, bg=CONFIG['cor_fundo'], highlightthickness=0)
    canvas_perfil.create_oval(10, 10, 110, 110, fill="#dddddd", outline="#cccccc", width=2)
    canvas_perfil.pack(pady=(0, 30))

# Frame para os campos de login
frame_campos = tkinter.Frame(frame_login, bg=CONFIG['cor_fundo'])
frame_campos.pack(pady=20)

# Label e campo para LOGIN
label_login = tkinter.Label(
    frame_campos,
    text="LOGIN:",
    font=("Arial", 12, "bold"),
    bg=CONFIG["cor_fundo"],
    fg="#333333",
    anchor='w'
)
label_login.grid(row=0, column=0, sticky='w', pady=(0, 5))

# Caixa de texto para login
entry_login = tkinter.Entry(
    frame_campos,
    font=CONFIG['fonte_campos'],
    width=25,
    relief='solid',
    bd=1
)
entry_login.grid(row=1, column=0, sticky='w', pady=(0, 20))

# Label e campo para SENHA
label_senha = tkinter.Label(
    frame_campos,
    text="SENHA:",
    font=("Arial", 12, "bold"),
    bg=CONFIG['cor_fundo'],
    fg="#333333",
    anchor='w'
)
label_senha.grid(row=2, column=0, sticky='w', pady=(0, 5))

# Caixa de texto para senha (com caracteres ocultos)
entry_senha = tkinter.Entry(
    frame_campos,
    font=CONFIG['fonte_campos'],
    width=25,
    show="*",  # Mostra asteriscos instead dos caracteres
    relief='solid',
    bd=1
)
entry_senha.grid(row=3, column=0, sticky='w', pady=(0, 30))

# Botão de acesso
botao_acessar = tkinter.Button(
    frame_campos,
    text="ACESSAR",
    font=("Arial", 12, "bold"),
    bg="#000000",
    fg="white",
    width=15,
    height=2,
    relief='flat'
)
botao_acessar.grid(row=4, column=0, pady=10)

# Foco no campo de login ao iniciar
entry_login.focus()

# Inicia o loop principal da interface
page01.mainloop()